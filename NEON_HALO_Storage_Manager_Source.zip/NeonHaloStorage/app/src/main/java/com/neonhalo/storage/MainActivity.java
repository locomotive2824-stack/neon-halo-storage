package com.neonhalo.storage;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_TREE = 41;
    private static final int OPEN_FILE = 42;
    private static final int BG = Color.rgb(8,5,19);
    private static final int PANEL = Color.rgb(20,17,39);
    private static final int CYAN = Color.rgb(0,255,213);
    private static final int GREEN = Color.rgb(100,255,90);
    private static final int WHITE = Color.rgb(235,245,255);

    private LinearLayout root, list;
    private TextView status, pathView;
    private Uri treeUri, currentUri;
    private final ArrayList<Uri> itemUris = new ArrayList<>();
    private final ArrayList<String> itemNames = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        status.setText("SYSTEM READY  //  STORAGE ACCESS NOT YET GRANTED");
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(12));
        root.setBackgroundColor(BG);
        setContentView(root);

        TextView logo = new TextView(this);
        logo.setText("N E O N   H A L O");
        logo.setTextColor(CYAN);
        logo.setTextSize(23);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        root.addView(logo);

        TextView subtitle = new TextView(this);
        subtitle.setText("STORAGE CORE  //  ARMv7 EDITION");
        subtitle.setTextColor(GREEN);
        subtitle.setTextSize(11);
        subtitle.setPadding(0, dp(3), 0, dp(14));
        root.addView(subtitle);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(buttons);
        addButton(buttons, "＋ CONNECT USB / SD", v -> pickStorage(), 1);
        addButton(buttons, "↻", v -> refresh(), 0);

        pathView = new TextView(this);
        pathView.setText("NO DRIVE CONNECTED");
        pathView.setTextColor(CYAN);
        pathView.setTextSize(12);
        pathView.setPadding(dp(10), dp(12), dp(10), dp(12));
        pathView.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(12);
        root.addView(pathView, pp);

        status = new TextView(this);
        status.setTextColor(GREEN);
        status.setTextSize(10);
        status.setPadding(0, dp(8), 0, dp(8));
        root.addView(status);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        root.addView(scroll, sp);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);

        TextView footer = new TextView(this);
        footer.setText("SAFE MODE  •  Android Storage Access Framework");
        footer.setTextColor(Color.rgb(115,125,155));
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(10), 0, 0);
        root.addView(footer);
        showEmpty("Connect a USB OTG drive or choose an SD-card folder.");
    }

    private void pickStorage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                   Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                   Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, PICK_TREE); }
        catch (Exception e) { toast("Storage picker unavailable on this device."); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == PICK_TREE) {
            try {
                getContentResolver().takePersistableUriPermission(uri,
                    data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
            } catch (Exception ignored) {}
            treeUri = uri;
            currentUri = uri;
            pathView.setText("ACTIVE ROOT  //  " + uri.getLastPathSegment());
            refresh();
        } else if (request == OPEN_FILE) {
            try {
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(uri, getContentResolver().getType(uri));
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(view);
            } catch (Exception e) { toast("No app available to open this file."); }
        }
    }

    private void refresh() {
        if (currentUri == null) { showEmpty("No storage selected. Tap CONNECT USB / SD."); return; }
        list.removeAllViews();
        itemUris.clear(); itemNames.clear();
        try {
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docIdFor(currentUri));
            String[] cols = { DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                              DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                              DocumentsContract.Document.COLUMN_MIME_TYPE,
                              DocumentsContract.Document.COLUMN_SIZE };
            try (Cursor c = getContentResolver().query(children, cols, null, null,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME + " ASC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        String id = c.getString(0), name = c.getString(1), mime = c.getString(2);
                        Uri u = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                        itemUris.add(u); itemNames.add(name);
                        addEntry(name, DocumentsContract.Document.MIME_TYPE_DIR.equals(mime), u);
                    }
                }
            }
            status.setText("INDEXED " + itemNames.size() + " ITEMS  //  READ/WRITE ACCESS GRANTED");
            pathView.setText("BROWSE  //  " + currentUri.getLastPathSegment());
            if (itemNames.isEmpty()) showEmpty("This folder is empty.");
        } catch (Exception e) {
            status.setText("ACCESS ERROR  //  RECONNECT OR SELECT A DIFFERENT FOLDER");
            showEmpty("Couldn't read this folder. The USB drive may have disconnected.");
        }
    }

    private String docIdFor(Uri uri) {
        // The tree URI itself has a tree document ID, not a document ID.
        if (treeUri != null && uri.equals(treeUri)) {
            return DocumentsContract.getTreeDocumentId(treeUri);
        }
        return DocumentsContract.getDocumentId(uri);
    }

    private void addEntry(String name, boolean directory, Uri uri) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(8), dp(12));
        row.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.bottomMargin = dp(5);
        list.addView(row, rp);

        TextView label = new TextView(this);
        label.setText((directory ? "▰  " : "◇  ") + name);
        label.setTextColor(directory ? CYAN : WHITE);
        label.setTextSize(14);
        label.setTypeface(Typeface.MONOSPACE);
        label.setMaxLines(2);
        row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

        Button action = smallButton(directory ? "OPEN" : "VIEW");
        row.addView(action);
        action.setOnClickListener(v -> {
            if (directory) { currentUri = uri; refresh(); }
            else openUri(uri);
        });
        row.setOnLongClickListener(v -> { showActions(name, uri, directory); return true; });
    }

    private void showActions(String name, Uri uri, boolean directory) {
        String[] options = directory
            ? new String[]{"Open folder", "Create folder here", "Delete"}
            : new String[]{"Open file", "Delete"};
        new AlertDialog.Builder(this).setTitle(name).setItems(options, (d, which) -> {
            String choice = options[which];
            if (choice.equals("Open folder")) { currentUri = uri; refresh(); }
            else if (choice.equals("Create folder here")) createFolder();
            else if (choice.equals("Open file")) openUri(uri);
            else if (choice.equals("Delete")) confirmDelete(name, uri);
        }).show();
    }

    private void openUri(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, getContentResolver().getType(uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) { toast("No compatible app found for this file."); }
    }

    private void createFolder() {
        if (currentUri == null) return;
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Folder name");
        new AlertDialog.Builder(this).setTitle("NEW DIRECTORY")
            .setView(input).setNegativeButton("CANCEL", null)
            .setPositiveButton("CREATE", (d, w) -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { toast("Enter a folder name."); return; }
                try {
                    Uri made = DocumentsContract.createDocument(getContentResolver(), currentUri,
                        DocumentsContract.Document.MIME_TYPE_DIR, name);
                    if (made == null) toast("Folder could not be created.");
                    refresh();
                } catch (Exception e) { toast("This drive doesn't allow folder creation here."); }
            }).show();
    }

    private void confirmDelete(String name, Uri uri) {
        new AlertDialog.Builder(this).setTitle("DELETE ITEM?")
            .setMessage("Delete \"" + name + "\"? This cannot always be undone.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("DELETE", (d, w) -> {
                try {
                    boolean ok = DocumentsContract.deleteDocument(getContentResolver(), uri);
                    toast(ok ? "Deleted." : "Delete was not completed.");
                    refresh();
                } catch (Exception e) { toast("Delete denied by storage provider."); }
            }).show();
    }

    private void addButton(LinearLayout parent, String text, View.OnClickListener listener, int weight) {
        Button b = smallButton(text);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(weight == 1 ? 0 : dp(52), dp(48), weight);
        p.rightMargin = dp(6);
        parent.addView(b, p);
        b.setOnClickListener(listener);
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(CYAN);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL));
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        return b;
    }

    private void showEmpty(String message) {
        if (list == null) return;
        list.removeAllViews();
        TextView t = new TextView(this);
        t.setText("\n  [ STORAGE NODE ]\n\n  " + message + "\n");
        t.setTextColor(Color.rgb(150,170,190));
        t.setTextSize(13);
        t.setPadding(dp(12), dp(20), dp(12), dp(20));
        list.addView(t);
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onBackPressed() {
        if (treeUri != null && currentUri != null && !currentUri.equals(treeUri)) {
            currentUri = treeUri;
            refresh();
        } else {
            super.onBackPressed();
        }
    }
}
