# NEON HALO Storage Manager — FOXX A55 build

A small native Android file manager starter for Android 13 / 32-bit ARMv7. The app uses Android's Storage Access Framework (SAF), so it does not need root or broad storage permissions.

## Included
- Neon sci-fi dark interface
- Select a USB OTG or SD-card directory through Android's system picker
- Browse folders and open files with installed apps
- Create folders
- Long-press an item to open actions; delete is confirmed first
- Persistable directory access where the storage provider supports it

## Important limits
- USB OTG only works if the phone, adapter, and drive support USB host mode and the drive receives enough power.
- Android 11+ restricts access to some protected folders, including `Android/data` and `Android/obb`.
- The picker may not expose every USB drive on every manufacturer build.
- This is source code, not a prebuilt APK. Build and install testing are still required on the actual FOXXD A55.

## Build
Requires Android SDK Platform 35, Build Tools 35.x, JDK 17, and Gradle 8.7. From this folder:

```sh
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

For ARMv7, this app has no native `.so` libraries, so it is not restricted to a CPU ABI.

## Quick test on FOXX A55
1. Install the debug APK.
2. Connect a USB OTG adapter and drive, or use your SD card.
3. Tap **CONNECT USB / SD**.
4. In Android's picker, select the drive or a folder on it and tap **Use this folder**.
5. Browse folders. Tap a file to open it; long-press items for actions.

## Safety
Deletion is permanent on some drives. Test with sample files first.
